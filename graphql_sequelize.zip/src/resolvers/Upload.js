const { GraphQLUpload } = require('graphql-yoga');

const Upload = {
    Upload: GraphQLUpload
}


module.exports = Upload;